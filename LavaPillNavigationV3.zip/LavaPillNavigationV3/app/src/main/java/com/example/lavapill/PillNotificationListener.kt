package com.example.lavapill

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class PillNotificationListener : NotificationListenerService() {
    private val active = HashSet<String>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        active.add(sbn.key)
        PillAccessibilityService.instance?.showNotification(active.size)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        active.remove(sbn.key)
        if (active.isEmpty()) PillAccessibilityService.instance?.hideNotification()
        else PillAccessibilityService.instance?.showNotification(active.size)
    }
}
