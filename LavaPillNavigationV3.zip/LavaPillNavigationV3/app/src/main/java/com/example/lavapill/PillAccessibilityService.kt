package com.example.lavapill

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import android.os.Handler
import android.os.Looper
import kotlin.math.abs

class PillAccessibilityService : AccessibilityService() {
    companion object { var instance: PillAccessibilityService? = null }

    private var wm: WindowManager? = null
    private var pill: LinearLayout? = null
    private var text: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var downX = 0f
    private var downY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        showPill()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun bg(expanded: Boolean): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(40).toFloat()
            setColor(Color.BLACK)
        }

    private fun showPill() {
        if (pill != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = bg(false)
            setPadding(dp(12), 0, dp(12), 0)
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; true }
                    MotionEvent.ACTION_UP -> {
                        val dx=e.rawX-downX; val dy=e.rawY-downY
                        handleGesture(dx,dy); true
                    }
                    else -> true
                }
            }
        }

        val label = TextView(this).apply {
            text = "━━━━━━"
            textSize = 10f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        text = label
        bar.addView(label)

        val params = WindowManager.LayoutParams(
            dp(108), dp(30),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = dp(10)
        pill=bar
        wm?.addView(bar, params)
    }

    fun showNotification(count: Int) {
        handler.post {
            pill?.let { view ->
                view.layoutParams.width = dp(180)
                view.background = bg(true)
                text?.text = if (count == 1) "●  New notification" else "●  $count notifications"
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({ hideNotification() }, 2500)
            }
        }
    }

    fun hideNotification() {
        handler.post {
            pill?.let {
                it.layoutParams.width = dp(108)
                it.background = bg(false)
                text?.text = "━━━━━━"
                it.requestLayout()
            }
        }
    }

    private fun handleGesture(dx:Float,dy:Float) {
        val t=dp(30).toFloat()
        when {
            dy < -t && abs(dy)>abs(dx) -> {
                if (dy < -dp(90)) performGlobalAction(GLOBAL_ACTION_RECENTS)
                else performGlobalAction(GLOBAL_ACTION_HOME)
            }
            abs(dx)>t && abs(dx)>abs(dy) -> performGlobalAction(GLOBAL_ACTION_BACK)
            else -> performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    fun stopPill() {
        pill?.let { runCatching { wm?.removeView(it) } }
        pill=null
    }

    override fun onDestroy() {
        stopPill()
        instance=null
        super.onDestroy()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
