package com.example.lavapill

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.os.Build
import android.content.pm.PackageManager

class MainActivity : Activity() {
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 45, 40, 30)
        }

        layout.addView(TextView(this).apply {
            text = "Lava Pill Navigation V3"
            textSize = 26f
            setTextColor(Color.BLACK)
        })

        layout.addView(TextView(this).apply {
            text = "\nSetup\n1. Enable Accessibility Service.\n2. Enable Notification Access.\n3. Return here. The pill can then work even when this app is minimized."
            textSize = 17f
        })

        layout.addView(button("① Enable Navigation Pill") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        layout.addView(button("② Enable Notification Access") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })

        layout.addView(button("③ Open App Notification Settings") {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            })
        })

        layout.addView(button("Stop Pill") {
            PillAccessibilityService.instance?.stopPill()
        })

        layout.addView(TextView(this).apply {
            text = "\nPermissions explained:\n• Accessibility: required for Home / Back / Recents.\n• Notification Access: lets the pill react to incoming notifications.\n• No Internet permission is used."
            textSize = 15f
        })

        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 100)
        }
    }
}
