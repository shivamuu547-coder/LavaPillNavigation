package com.example.lavapill

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // AccessibilityService is managed by Android and is restarted by the system
        // when the user has enabled it. Nothing needs to be launched here.
    }
}
